
/**
 * @author Thomas Lerner
 *
 *This class is just meant to store character and frequency data for use in an arraylist
 */
public class FreqData {
	
	public Character data;
	
	public Integer frequency;
	
	public FreqData (Character data, Integer frequency) {
		this.data = data;
		this.frequency = frequency;
	}
	
	
}
